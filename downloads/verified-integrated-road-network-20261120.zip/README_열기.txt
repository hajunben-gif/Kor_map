부여군·청양군 검증 통합 도로망 · 2026-11-20 PBF

1. integrated_road_network_20261120.html을 Chrome/Edge로 여세요.
2. 인터넷 연결이 필요합니다(OpenFreeMap 배경, Leaflet/MapLibre JS·CSS).
3. 오른쪽 위에서 Drive / Drive+Service / 구호차량 후보망을 선택하세요.
4. 초록색은 시설, 빨간색은 QA 보정 시설입니다. 시설을 클릭하면 최근접 거리와 연결 적격 거리가 표시됩니다.
5. 파란 선은 일반도로, 주황 선은 Service 도로이며 실제 구호차량 통행 가능 여부는 미확인입니다.

원자료 및 코드: https://github.com/hajunben-gif/Kor_map
분석 출처: OpenStreetMap contributors / ODbL 1.0
배경 지도: OpenFreeMap / OpenStreetMap contributors
이 자료는 침수·실제 주행거리·회전 제한·현장 출입구를 검증한 결과가 아닙니다.
